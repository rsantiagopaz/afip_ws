-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 06-03-2019 a las 05:47:10
-- Versión del servidor: 10.1.31-MariaDB
-- Versión de PHP: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `afip_ws_homologacion`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ws_documento`
--

CREATE TABLE `ws_documento` (
  `id_ws_documento` int(11) NOT NULL,
  `id_ws_solicitud` int(11) DEFAULT NULL,
  `id_ws_wsaa` int(11) DEFAULT NULL,
  `id_ws_wsfev1` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ws_solicitud`
--

CREATE TABLE `ws_solicitud` (
  `id_ws_solicitud` int(11) NOT NULL,
  `id_ws_wsaa` int(11) DEFAULT NULL,
  `id_ws_wsfev1` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ws_wsaa`
--

CREATE TABLE `ws_wsaa` (
  `id_ws_wsaa` int(11) NOT NULL,
  `resultado` varchar(1) COLLATE utf8_spanish_ci DEFAULT NULL,
  `texto_respuesta` text COLLATE utf8_spanish_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ws_wsfev1`
--

CREATE TABLE `ws_wsfev1` (
  `id_ws_wsfev1` int(11) NOT NULL,
  `resultado` varchar(1) COLLATE utf8_spanish_ci DEFAULT NULL,
  `texto_solicitud` text COLLATE utf8_spanish_ci,
  `texto_respuesta` text COLLATE utf8_spanish_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `ws_documento`
--
ALTER TABLE `ws_documento`
  ADD PRIMARY KEY (`id_ws_documento`);

--
-- Indices de la tabla `ws_solicitud`
--
ALTER TABLE `ws_solicitud`
  ADD PRIMARY KEY (`id_ws_solicitud`);

--
-- Indices de la tabla `ws_wsaa`
--
ALTER TABLE `ws_wsaa`
  ADD PRIMARY KEY (`id_ws_wsaa`);

--
-- Indices de la tabla `ws_wsfev1`
--
ALTER TABLE `ws_wsfev1`
  ADD PRIMARY KEY (`id_ws_wsfev1`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `ws_documento`
--
ALTER TABLE `ws_documento`
  MODIFY `id_ws_documento` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `ws_solicitud`
--
ALTER TABLE `ws_solicitud`
  MODIFY `id_ws_solicitud` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `ws_wsaa`
--
ALTER TABLE `ws_wsaa`
  MODIFY `id_ws_wsaa` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `ws_wsfev1`
--
ALTER TABLE `ws_wsfev1`
  MODIFY `id_ws_wsfev1` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
